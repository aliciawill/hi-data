function call(){
	alert('i am a java programmer')
}