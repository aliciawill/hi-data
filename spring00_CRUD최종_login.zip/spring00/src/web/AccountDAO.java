package web;

public class AccountDAO {
	//CRUD
	
	//create 기능만 호출. vo만들어서 넣어서 전달, 확인
}
